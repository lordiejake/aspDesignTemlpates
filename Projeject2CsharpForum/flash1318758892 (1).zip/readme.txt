How to add your Flash Tag Cloud on your homepage
================================================

- Open the Sample HTML-File from your download package with your favorite HTML-Editor.


If you have a homepage with "AC_RunActiveContent.js", you can skip this step.
- Copy the two <script> lines from the <head> block to your homepage header.


- Copy the <script> and <noscript> block to the location on your homepage where the Flash Tag Cloud should be added.

- Upload the *.swf, *.xml and (if needed "AC_RunActiveContent.js") on your webspace, normally to the webroot.
